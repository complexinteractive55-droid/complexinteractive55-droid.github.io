// Motor de composición; no contiene ni inventa un membrete institucional.
// Requiere PDF, fuentes y reglas de página aprobados y verificados por el servidor.
/**
 * @param {*} lib
 * @param {*} doc
 * @param {*} assets
 * @param {{preview?: boolean, fontkit?: object | null}} [options]
 */
export async function renderModeloV2PDF(lib,doc,assets,{preview=false,fontkit=null}={}){
 const {PDFDocument,StandardFonts,rgb}=lib,cfg=doc.plantilla?.configuracion;
 if(!cfg||cfg.formato_version!==1)throw Error('Falta configurar la plantilla oficial.');
 const source=await PDFDocument.load(assets.pdf,{updateMetadata:false});
 const pdf=await PDFDocument.create();if(fontkit)pdf.registerFontkit(fontkit);
 const fontCfg=cfg.tipografia;
 const finite=(v,min,max)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
 if(!fontCfg||!finite(fontCfg.tamano,8,24)||!finite(fontCfg.interlineado,fontCfg.tamano,42)||!finite(fontCfg.espacio_parrafo,0,30))throw Error('La tipografía institucional no está configurada.');
 let regular,bold;
 if(assets.normal||assets.negrita){if(!assets.normal||!assets.negrita||!fontkit)throw Error('Faltan las fuentes oficiales.');regular=await pdf.embedFont(assets.normal,{subset:true});bold=await pdf.embedFont(assets.negrita,{subset:true});}
 else{if(!Object.values(StandardFonts).includes(fontCfg.normal)||!Object.values(StandardFonts).includes(fontCfg.negrita))throw Error('Falta cargar la tipografía oficial.');regular=await pdf.embedFont(fontCfg.normal);bold=await pdf.embedFont(fontCfg.negrita);}
 const tracking=fontCfg.espaciado_caracteres;if(!finite(tracking,-.3,.3))throw Error('Falta definir el espaciado institucional.');
 const size=fontCfg.tamano,lineHeight=fontCfg.interlineado,gap=fontCfg.espacio_parrafo;
 const layouts=['primera','continuacion'].map(key=>{const v=cfg[key],a=v?.area;if(!v||!Number.isInteger(v.pagina)||v.pagina<0||v.pagina>=source.getPageCount()||!a)throw Error('Faltan las reglas aprobadas para la primera página o su continuación.');const page=source.getPage(v.pagina),{width,height}=page.getSize();if(!finite(a.x,0,width)||!finite(a.y,0,height)||!finite(a.ancho,150,width)||!finite(a.alto,100,height)||a.x+a.ancho>width||a.y+a.alto>height)throw Error('El área de texto invade el membrete o el pie.');return{...v,area:a,width,height};});
 const bodyWidth=Math.min(...layouts.map(l=>l.area.ancho));
 const embedded=await pdf.embedPages(layouts.map(l=>source.getPage(l.pagina)));
 let page,area,y,bottom,layout,fontKeys;const trace=[];
 function newPage(){if(pdf.getPageCount()>=200)throw Error('El documento supera las 200 páginas permitidas.');const index=pdf.getPageCount()===0?0:1;layout=layouts[index];area=layout.area;page=pdf.addPage([layout.width,layout.height]);fontKeys=new Map();page.drawPage(embedded[index],{x:0,y:0,width:layout.width,height:layout.height});y=area.y+area.alto-size;bottom=area.y+size*.3;}
 function measure(t,b){try{return(b?bold:regular).widthOfTextAtSize(t,size)+Array.from(t).length*tracking;}catch{throw Error('El texto contiene un carácter que no admite la fuente oficial. Revisa el contenido o la tipografía de la plantilla.');}}
 function wrap(runs,width){const lines=[];let line=[],used=0;
  function add(text,b,u=false){if(!text)return;const last=line[line.length-1];if(last&&last.bold===b&&last.underline===u)last.text+=text;else line.push({text,bold:b,underline:u});used+=measure(text,b);}
  function flush(hard=false){while(line.length){const last=line[line.length-1];last.text=last.text.trimEnd();if(last.text)break;line.pop();}line.hard=hard;lines.push(line);line=[];used=0;}
  for(const run of runs){for(const token of String(run.texto).replace(/\r\n?/g,'\n').replace(/\t/g,'    ').match(/\n|[^\S\n]+|[^\s]+/gu)||[]){if(token==='\n'){flush(true);continue;}if(/^\s+$/.test(token)){if(line.length&&used+measure(token,run.negrita)<=width)add(token,run.negrita,Boolean(run.subrayado));continue;}
   if(used+measure(token,run.negrita)>width&&line.length)flush();
   if(measure(token,run.negrita)<=width){add(token,run.negrita,Boolean(run.subrayado));continue;}
   for(const char of Array.from(token)){if(used+measure(char,run.negrita)>width&&line.length)flush();if(measure(char,run.negrita)>width)throw Error('La plantilla no tiene suficiente espacio para el texto.');add(char,run.negrita,Boolean(run.subrayado));}
  }}if(line.length||!lines.length)flush();return lines;
 }
 function drawParts(parts,x,baseline=y,justifyWidth=null){
  const expanded=justifyWidth===null?parts:parts.flatMap(p=>(p.text.match(/ +|[^ ]+/gu)||[]).map(text=>({...p,text})));
  const natural=expanded.reduce((n,p)=>n+measure(p.text,p.bold),0),spaces=expanded.reduce((n,p)=>n+(p.text.match(/ /g)||[]).length,0);
  const extra=justifyWidth!==null&&spaces?Math.max(0,(justifyWidth-natural)/spaces):0;let cursor=x;
  for(const p of expanded){if(!p.text)continue;const width=measure(p.text,p.bold);const font=p.bold?bold:regular;if(!fontKeys.has(font))fontKeys.set(font,page.node.newFontDictionary(font.name,font.ref));
   page.pushOperators(lib.pushGraphicsState(),lib.setFillingRgbColor(0,0,0),lib.beginText(),lib.setFontAndSize(fontKeys.get(font),size),lib.setCharacterSpacing(tracking),lib.moveText(cursor,baseline),lib.showText(font.encodeText(p.text)),lib.endText(),lib.popGraphicsState());if(p.underline&&p.text.trim())page.drawLine({start:{x:cursor,y:baseline-1.4},end:{x:cursor+width,y:baseline-1.4},thickness:.55,color:rgb(0,0,0)});trace.push({page:pdf.getPageCount(),x:cursor,y:baseline,width,size,text:p.text,bold:p.bold,area:{...area}});cursor+=width+extra*(p.text.match(/ /g)||[]).length;}
 }
 function line(parts,x,justifyWidth=null){drawParts(parts,x,y,justifyWidth);y-=lineHeight;}
 function paragraph(runs,{marker=null,inset=0,after=gap}={}){
  let content=runs.map(r=>({...r}));
  if(marker===null&&content.length){const text=content.map(r=>r.texto).join(''),m=text.match(/^([ \t]*)([a-z]|[0-9]{1,3})[.)]\s+/u),leading=text.match(/^[ \t]+/u)?.[0]||'';let cut=0;
   if(m){marker=m[2]+'.';inset=/[a-z]/.test(m[2])?36:18;cut=m[0].length;after=0;}
   else if(leading){inset=Math.min(72,leading.replace(/\t/g,'    ').length/4*18);cut=leading.length;}
   for(const r of content){const n=Math.min(cut,r.texto.length);r.texto=r.texto.slice(n);cut-=n;}
  }
  const hang=marker===null?0:Math.max(18,measure(marker||'1.',true)+6),indent=inset+hang,width=bodyWidth-indent;
  const lines=wrap(content,width);let offset=0;
  if(lines.length>1&&Math.floor((y-bottom)/lineHeight)+1<2)newPage();
  while(offset<lines.length){let room=Math.floor((y-bottom)/lineHeight)+1;if(room<1){newPage();room=Math.floor((y-bottom)/lineHeight)+1;}let count=Math.min(room,lines.length-offset);if(lines.length-offset-count===1&&count>2)count--;
   for(let i=0;i<count;i++){if(offset===0&&marker!==null){if(marker==='')page.drawCircle({x:area.x+inset+3,y:y+size*.3,size:1.6,color:rgb(0,0,0)});else drawParts([{text:marker,bold:true}],area.x+inset);}
    const parts=lines[offset];line(parts,area.x+indent,offset<lines.length-1&&!parts.hard?width:null);offset++;}
   if(offset<lines.length)newPage();
  }y-=after;
 }
 newPage();
 const dateParts=new Intl.DateTimeFormat('es-CO',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}).formatToParts(new Date(doc.datos.fecha_emision+'T12:00:00Z'));
 const part=type=>dateParts.find(p=>p.type===type)?.value;const date=part('day')+' de '+part('month')+' '+part('year');
 if(cfg.estructura==='memorando-institucional-v2'){
  const c=cfg.cuadro;
  if(!c||!finite(c.columna_izquierda,100,bodyWidth-100)||!finite(c.relleno_x,2,15)||!finite(c.relleno_y,0,10)||!finite(c.grosor_borde,.2,2)||!finite(c.espacio_asunto,0,50)||!finite(c.espacio_cuerpo,0,50)||!['izquierda','derecha','centro'].includes(c.asunto_alineacion)||typeof c.asunto_subrayado!=='boolean')throw Error('Falta configurar el cuadro de datos institucional.');
  if(!finite(c.interlineado,10,24)||!finite(c.primera_linea,9,20)||!finite(c.asunto_sangria_derecha,0,60))throw Error('El cuadro institucional requiere medidas válidas.');
  const left=c.columna_izquierda,right=bodyWidth-left,pad=c.relleno_x;
  const fields=[
   [wrap([{texto:'Fecha: ',negrita:true},{texto:date,negrita:false}],left-pad*2),wrap([{texto:'De: ',negrita:true},{texto:doc.datos.dependencia,negrita:false}],right-pad*2)],
   [[...wrap([{texto:'Consecutivo:',negrita:true}],left-pad*2),...wrap([{texto:preview?'Sin número definitivo':'N.º '+doc.numero,negrita:false}],left-pad*2)],[...wrap([{texto:'Para:',negrita:true}],right-pad*2),...wrap([{texto:doc.datos.destinatarios,negrita:false}],right-pad*2)]]
  ];
  let tableTop=area.y+area.alto;
  for(const row of fields){const height=Math.max(...row.map(lines=>lines.length))*c.interlineado+c.relleno_y*2;
   if(tableTop-height<bottom+lineHeight*2)throw Error('Los datos de destinatarios o dependencia no caben en el cuadro institucional.');
   for(let col=0;col<2;col++){const x=area.x+(col?left:0),width=col?right:left;page.drawRectangle({x,y:tableTop-height,width,height,borderWidth:c.grosor_borde,borderColor:rgb(0,0,0)});row[col].forEach((parts,i)=>drawParts(parts,x+pad,tableTop-c.primera_linea-i*c.interlineado));}
   tableTop-=height;
  }
  y=tableTop-c.espacio_asunto-size;
  const subject=wrap([{texto:'Asunto: ',negrita:true},{texto:doc.datos.titulo,negrita:false,subrayado:c.asunto_subrayado}],bodyWidth-c.asunto_sangria_derecha);
  for(const parts of subject){if(y<bottom+lineHeight*2)throw Error('El asunto no cabe bajo el cuadro institucional.');const width=parts.reduce((n,p)=>n+measure(p.text,p.bold),0),subjectWidth=bodyWidth-c.asunto_sangria_derecha,offset=c.asunto_alineacion==='derecha'?subjectWidth-width:c.asunto_alineacion==='centro'?(subjectWidth-width)/2:0;line(parts,area.x+offset);}
  y-=c.espacio_cuerpo;
 }else if(cfg.estructura===undefined){
  const meta=[['Circular N.º ',preview?'Sin número definitivo':String(doc.numero)],['Fecha: ',date],['Para: ',doc.datos.destinatarios],['Asunto: ',doc.datos.titulo],['Dependencia emisora: ',doc.datos.dependencia]];
  for(const[label,value]of meta)paragraph([{texto:label,negrita:true},{texto:value,negrita:false}]);
 }else throw Error('La estructura institucional no está reconocida.');
 if(preview){const notice='VISTA PREVIA - DOCUMENTO SIN FINALIZAR';pdf.getPage(0).drawText(notice,{x:layouts[0].area.x,y:layouts[0].area.y+layouts[0].area.alto+11,size:7.5,font:regular,color:rgb(.35,.35,.35)});}
 for(const block of doc.datos.contenido.bloques){if(block.tipo==='parrafo')paragraph(block.segmentos);else block.elementos.forEach((item,i)=>paragraph(item.segmentos,{marker:block.ordenada?(i+1)+'.':'',inset:18,after:0}));}
 const signature=cfg.firma;if(!signature||!finite(signature.espacio,0,120)||typeof signature.linea!=='boolean'||!finite(signature.ancho_linea,0,Math.min(layouts[0].area.ancho,layouts[1].area.ancho)))throw Error('Falta definir la zona de firma institucional.');
 if(signature.despedida!==undefined&&(typeof signature.despedida!=='string'||signature.despedida.length>120))throw Error('La despedida institucional no es válida.');
 if(signature.incluir_institucion!==undefined&&typeof signature.incluir_institucion!=='boolean')throw Error('La firma institucional no está configurada.');
 const signatureRuns=[{texto:doc.datos.responsable.toLocaleUpperCase('es-CO'),negrita:true},{texto:doc.datos.cargo,negrita:false},...(signature.incluir_institucion?[{texto:doc.institucion.nombre,negrita:false}]:[])];
 const closingLines=signature.despedida?wrap([{texto:signature.despedida,negrita:false}],bodyWidth):[];
 const signatureLines=signatureRuns.flatMap(r=>wrap([r],bodyWidth));const needed=(closingLines.length+signatureLines.length-1)*lineHeight+signature.espacio+(signature.linea?size:0);
 if(!finite(signature.antes_despedida,0,80))throw Error('Falta definir el cierre institucional.');
 if(needed>layouts[1].area.alto-size)throw Error('La zona de firma no cabe en la plantilla aprobada.');
 if(y-signature.antes_despedida-needed<bottom)newPage();else y-=signature.antes_despedida;
 for(const parts of closingLines)line(parts,area.x);y-=signature.espacio;
 if(signature.linea){page.drawLine({start:{x:area.x,y:y+size*.7},end:{x:area.x+signature.ancho_linea,y:y+size*.7},thickness:.6,color:rgb(0,0,0)});y-=size;}
 for(const parts of signatureLines)line(parts,area.x);
 const paging=cfg.paginacion;
 if(!paging||typeof paging.mostrar!=='boolean')throw Error('Falta definir la numeración de páginas institucional.');
 if(paging.mostrar){if(typeof paging.formato!=='string'||!paging.formato.includes('{pagina}')||!finite(paging.tamano,6,14)||!finite(paging.x,0,2000)||!finite(paging.y,0,2000)||!finite(paging.ancho,20,2000)||!['izquierda','derecha','centro'].includes(paging.alineacion))throw Error('La numeración de páginas no está configurada.');
  for(let i=0;i<pdf.getPageCount();i++){const p=pdf.getPage(i),t=paging.formato.replaceAll('{pagina}',String(i+1)).replaceAll('{paginas}',String(pdf.getPageCount())),w=regular.widthOfTextAtSize(t,paging.tamano);if(w>paging.ancho||paging.x+paging.ancho>p.getWidth()||paging.y<paging.tamano*.3||paging.y+paging.tamano>p.getHeight())throw Error('La numeración de páginas sale del espacio aprobado.');const x=paging.x+(paging.alineacion==='derecha'?paging.ancho-w:paging.alineacion==='centro'?(paging.ancho-w)/2:0);p.drawText(t,{x,y:paging.y,size:paging.tamano,font:regular});}
 }
 const created=new Date(doc.finalizada_en||'2000-01-01T00:00:00Z');pdf.setCreationDate(created);pdf.setModificationDate(created);pdf.setTitle(doc.datos.titulo);pdf.setSubject('Circular institucional');pdf.setAuthor(doc.institucion.nombre);pdf.setCreator('Complex_');pdf.setLanguage('es-CO');
 return{bytes:await pdf.save({useObjectStreams:false}),pages:pdf.getPageCount(),trace};
}


