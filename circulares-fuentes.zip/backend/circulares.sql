-- Complex_: ampliación autorizada de circulares. FUENTE PARA PRUEBAS AISLADAS.
-- No aplicar a producción hasta tener plantilla oficial aprobada y pruebas superadas.
begin;
alter table public.circulares add column finalizada_en timestamptz;
create unique index circulares_numero_unico on public.circulares(colegio_id,numero) where numero is not null;

create table private.circular_consecutivos(
 colegio_id uuid primary key references public.colegios(id) on delete cascade,
 ultimo integer not null check(ultimo>=0)
);
revoke all on private.circular_consecutivos from public,anon,authenticated;
create table public.circular_plantillas(
 id uuid primary key default gen_random_uuid(),
 colegio_id uuid not null references public.colegios(id) on delete cascade,
 nombre text not null check(length(trim(nombre)) between 1 and 160),
 revision integer not null check(revision>0),
 estado text not null default 'pendiente' check(estado in('pendiente','aprobada','archivada')),
 ruta text not null,
 sha256 text not null check(sha256 ~ '^[0-9a-f]{64}$'),
 configuracion jsonb not null check(jsonb_typeof(configuracion)='object'),
 fuentes jsonb not null default '{}' check(jsonb_typeof(fuentes)='object'),
 aprobada_por uuid references public.perfiles(id),
 aprobada_en timestamptz,
 creado_en timestamptz not null default now(),
 unique(colegio_id,id), unique(colegio_id,revision),
 check(ruta like colegio_id::text||'/%'),
 check(estado<>'aprobada' or (aprobada_por is not null and aprobada_en is not null))
);
create table public.circular_documentos(
 circular_id uuid primary key,
 colegio_id uuid not null,
 solicitud_id uuid not null,
 huella text not null check(huella ~ '^[0-9a-f]{64}$'),
 plantilla_id uuid not null,
 datos jsonb not null check(jsonb_typeof(datos)='object'),
 institucion jsonb not null check(jsonb_typeof(institucion)='object'),
 plantilla jsonb not null check(jsonb_typeof(plantilla)='object'),
 pdf_estado text not null default 'pendiente' check(pdf_estado in('pendiente','generando','listo','error')),
 pdf_ruta text,
 pdf_sha256 text check(pdf_sha256 is null or pdf_sha256 ~ '^[0-9a-f]{64}$'),
 pdf_error text,
 intento_token uuid,
 intento_hasta timestamptz,
 intentos integer not null default 0,
 creado_en timestamptz not null default now(),
 unique(colegio_id,solicitud_id),
 foreign key(colegio_id,circular_id) references public.circulares(colegio_id,id) on delete cascade,
 foreign key(colegio_id,plantilla_id) references public.circular_plantillas(colegio_id,id),
 check(pdf_ruta is null or pdf_ruta like colegio_id::text||'/'||circular_id::text||'/%'),
 check(pdf_estado<>'listo' or (pdf_ruta is not null and pdf_sha256 is not null))
);
create index circular_documentos_colegio_fecha on public.circular_documentos(colegio_id,creado_en desc);
alter table public.circular_plantillas enable row level security;
alter table public.circular_documentos enable row level security;
revoke all on public.circular_plantillas,public.circular_documentos from public,anon,authenticated;
grant select on public.circular_plantillas,public.circular_documentos to authenticated;
grant all on public.circular_plantillas,public.circular_documentos to service_role;
create policy plantilla_circular_admin_ver on public.circular_plantillas for select to authenticated using(private.es_admin(colegio_id));
create policy documento_circular_admin_ver on public.circular_documentos for select to authenticated using(private.es_admin(colegio_id));

create or replace function private.siguiente_circular(p_colegio uuid)
returns integer language plpgsql security definer set search_path='' as $$
declare v_max integer;v_num integer;
begin
 perform pg_advisory_xact_lock(hashtext('circular_'||p_colegio::text));
 select coalesce(max(numero),0) into v_max from public.circulares where colegio_id=p_colegio;
 insert into private.circular_consecutivos as cc(colegio_id,ultimo) values(p_colegio,v_max+1)
 on conflict(colegio_id) do update set ultimo=greatest(cc.ultimo,v_max)+1
 returning ultimo into v_num;
 return v_num;
end $$;
create or replace function private.numerar_circular()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='INSERT' and new.numero is not null then raise exception 'El número se asigna en el servidor.';end if;
 if tg_op='UPDATE' then
  if new.numero is distinct from old.numero then raise exception 'El número de una circular no se puede cambiar manualmente.';end if;
  if old.finalizada_en is not null and
   (new.colegio_id,new.autor_id,new.titulo,new.cuerpo,new.finalizada_en) is distinct from
   (old.colegio_id,old.autor_id,old.titulo,old.cuerpo,old.finalizada_en)
  then raise exception 'El contenido de una circular finalizada no se puede modificar.';end if;
 end if;
 if (new.finalizada_en is not null or new.publicada_en is not null) and new.numero is null then
  new.numero:=private.siguiente_circular(new.colegio_id);
 end if;
 return new;
end $$;
-- Se conserva el disparador existente numerar_circular y la publicación separada.

create function private.validar_segmentos_circular(p_segmentos jsonb)
returns text language plpgsql immutable set search_path='' as $$
declare s jsonb;t text;resultado text:='';
begin
 if jsonb_typeof(p_segmentos) is distinct from 'array' or jsonb_array_length(p_segmentos) not between 1 and 200 then raise exception 'Revisa los párrafos del cuerpo.';end if;
 for s in select value from jsonb_array_elements(p_segmentos) loop
  if jsonb_typeof(s) is distinct from 'object' or s-array['texto','negrita']<>'{}'::jsonb or jsonb_typeof(s->'texto') is distinct from 'string' or jsonb_typeof(s->'negrita') is distinct from 'boolean' then raise exception 'El formato del cuerpo no es válido.';end if;
  t:=s->>'texto';
  if regexp_replace(t,E'[\n\r\t]','','g') ~ '[[:cntrl:]]' then raise exception 'El cuerpo contiene caracteres no permitidos.';end if;
  resultado:=resultado||t;
 end loop;
 return resultado;
end $$;
create function private.validar_datos_circular(p jsonb)
returns jsonb language plpgsql immutable set search_path='' as $$
declare campo text;limite integer;v text;c jsonb;b jsonb;e jsonb;plano text:='';n integer;f date;canon jsonb:='{}';
begin
 if jsonb_typeof(p) is distinct from 'object' or p-array['titulo','destinatarios','dependencia','responsable','cargo','fecha_emision','contenido']<>'{}'::jsonb then raise exception 'Los datos de la circular no son válidos.';end if;
 foreach campo in array array['titulo','destinatarios','dependencia','responsable','cargo'] loop
  limite:=case campo when 'titulo' then 250 when 'destinatarios' then 1000 when 'dependencia' then 160 when 'responsable' then 200 else 160 end;
  if jsonb_typeof(p->campo) is distinct from 'string' then raise exception 'Completa el campo %.',campo;end if;
  v:=btrim(p->>campo);
  if length(v) not between 1 and limite or regexp_replace(v,E'[\n\r\t]','','g') ~ '[[:cntrl:]]' then raise exception 'Revisa el campo % (máximo % caracteres).',campo,limite;end if;
  canon:=canon||jsonb_build_object(campo,v);
 end loop;
 v:=p->>'fecha_emision';
 if v is null or v !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Escribe una fecha de emisión válida.';end if;
 begin f:=v::date;exception when others then raise exception 'Escribe una fecha de emisión válida.';end;
 if to_char(f,'YYYY-MM-DD')<>v then raise exception 'Escribe una fecha de emisión válida.';end if;
 c:=p->'contenido';
 if jsonb_typeof(c) is distinct from 'object' or c-array['version','bloques']<>'{}'::jsonb or c->'version' is distinct from '1'::jsonb or jsonb_typeof(c->'bloques') is distinct from 'array' then raise exception 'Revisa el formato del cuerpo.';end if;
 if jsonb_array_length(c->'bloques') not between 1 and 400 then raise exception 'El cuerpo admite hasta 400 bloques.';end if;
 for b in select value from jsonb_array_elements(c->'bloques') loop
  if jsonb_typeof(b) is distinct from 'object' then raise exception 'Revisa los bloques del cuerpo.';end if;
  if b->>'tipo'='parrafo' then
   if b-array['tipo','segmentos']<>'{}'::jsonb then raise exception 'Formato de párrafo no permitido.';end if;
   plano:=plano||private.validar_segmentos_circular(b->'segmentos')||E'\n\n';
  elsif b->>'tipo'='lista' then
   if b-array['tipo','ordenada','elementos']<>'{}'::jsonb or jsonb_typeof(b->'ordenada') is distinct from 'boolean' or jsonb_typeof(b->'elementos') is distinct from 'array' then raise exception 'Revisa las listas del cuerpo.';end if;
   if jsonb_array_length(b->'elementos') not between 1 and 200 then raise exception 'Revisa la longitud de las listas.';end if;
   n:=0;
   for e in select value from jsonb_array_elements(b->'elementos') loop
    if jsonb_typeof(e) is distinct from 'object' or e-array['segmentos']<>'{}'::jsonb then raise exception 'Formato de lista no permitido.';end if;
    n:=n+1;plano:=plano||case when (b->>'ordenada')::boolean then n::text||'. ' else '- ' end||private.validar_segmentos_circular(e->'segmentos')||E'\n';
   end loop;
  else raise exception 'El cuerpo solo admite párrafos, negrita y listas.';
  end if;
 end loop;
 if btrim(plano)='' or length(plano)>80000 then raise exception 'Escribe un cuerpo de hasta 80.000 caracteres.';end if;
 return canon||jsonb_build_object('fecha_emision',v,'contenido',c,'texto_plano',plano);
end $$;

create function private.presentar_circular_documento(p_id uuid)
returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('id',c.id,'colegio_id',c.colegio_id,'numero',c.numero,'titulo',c.titulo,
 'finalizada_en',c.finalizada_en,'publicada_en',c.publicada_en,'fecha_emision',d.datos->>'fecha_emision',
 'datos',d.datos-'texto_plano','institucion',d.institucion,'plantilla',d.plantilla,
 'pdf_estado',d.pdf_estado,'pdf_error',d.pdf_error,'pdf_ruta',d.pdf_ruta,'pdf_sha256',d.pdf_sha256)
 from public.circulares c join public.circular_documentos d on d.circular_id=c.id where c.id=p_id;
$$;
create function public.finalizar_circular_documento(p_colegio uuid,p_solicitud uuid,p_plantilla uuid,p_datos jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare v_datos jsonb;v_huella text;existente public.circular_documentos;plant public.circular_plantillas;inst jsonb;v_id uuid;
begin
 if (select auth.uid()) is null or not private.es_admin(p_colegio) then raise exception using errcode='42501',message='Solo Administración puede finalizar circulares de este colegio.';end if;
 if p_solicitud is null or p_plantilla is null then raise exception 'Falta la identificación de la operación o la plantilla oficial.';end if;
 v_datos:=private.validar_datos_circular(p_datos);
 v_huella:=encode(sha256(convert_to(jsonb_build_object('datos',v_datos,'plantilla_id',p_plantilla)::text,'UTF8')),'hex');
 perform pg_advisory_xact_lock(hashtext('circular_'||p_colegio::text));
 select * into existente from public.circular_documentos where colegio_id=p_colegio and solicitud_id=p_solicitud;
 if found then
  if existente.huella<>v_huella then raise exception using errcode='22000',message='Esta operación ya corresponde a otra versión del contenido.';end if;
  return private.presentar_circular_documento(existente.circular_id);
 end if;
 select * into plant from public.circular_plantillas where id=p_plantilla and colegio_id=p_colegio and estado='aprobada' for share;
 if not found then raise exception 'Falta la plantilla institucional oficial aprobada.';end if;
 select jsonb_build_object('id',id,'nombre',nombre,'nit',nit,'ciudad',ciudad) into inst from public.colegios where id=p_colegio;
 insert into public.circulares(colegio_id,autor_id,titulo,cuerpo,finalizada_en)
 values(p_colegio,(select auth.uid()),v_datos->>'titulo',v_datos->>'texto_plano',now()) returning id into v_id;
 insert into public.circular_documentos(circular_id,colegio_id,solicitud_id,huella,plantilla_id,datos,institucion,plantilla)
 values(v_id,p_colegio,p_solicitud,v_huella,plant.id,v_datos,inst,
 jsonb_build_object('id',plant.id,'nombre',plant.nombre,'revision',plant.revision,'ruta',plant.ruta,'sha256',plant.sha256,'configuracion',plant.configuracion,'fuentes',plant.fuentes));
 return private.presentar_circular_documento(v_id);
end $$;
create function public.obtener_circular_documento(p_id uuid)
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare v_colegio uuid;
begin
 select colegio_id into v_colegio from public.circulares where id=p_id;
 if (select auth.uid()) is null or v_colegio is null or not private.es_admin(v_colegio) then raise exception using errcode='42501',message='No tienes acceso a esa circular.';end if;
 return private.presentar_circular_documento(p_id);
end $$;
create function public.listar_circular_documentos(p_colegio uuid)
returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if (select auth.uid()) is null or not private.es_admin(p_colegio) then raise exception using errcode='42501',message='Solo Administración puede gestionar estas circulares.';end if;
 return coalesce((select jsonb_agg(x order by x.creado_en desc) from
 (select c.id,c.numero,c.titulo,c.finalizada_en,d.pdf_estado,d.pdf_error,d.creado_en,d.datos->>'fecha_emision' as fecha_emision from public.circulares c join public.circular_documentos d on d.circular_id=c.id where c.colegio_id=p_colegio order by d.creado_en desc limit 100) x),'[]'::jsonb);
end $$;
create function public.reclamar_pdf_circular(p_id uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare d public.circular_documentos;v_token uuid;
begin
 select * into d from public.circular_documentos where circular_id=p_id for update;
 if not found then raise exception 'No existe el documento guardado.';end if;
 if d.pdf_estado='listo' then return jsonb_build_object('accion','listo','documento',private.presentar_circular_documento(p_id));end if;
 if d.pdf_estado='generando' and d.intento_hasta>now() then return jsonb_build_object('accion','ocupado','documento',private.presentar_circular_documento(p_id));end if;
 v_token:=gen_random_uuid();
 update public.circular_documentos set pdf_estado='generando',pdf_error=null,intento_token=v_token,intento_hasta=now()+interval '3 minutes',intentos=intentos+1 where circular_id=p_id;
 return jsonb_build_object('accion','generar','token',v_token,'documento',private.presentar_circular_documento(p_id));
end $$;
create function public.terminar_pdf_circular(p_id uuid,p_token uuid,p_ruta text,p_sha256 text,p_error text default null)
returns boolean language plpgsql security definer set search_path='' as $$
declare n integer;
begin
 if p_error is null and (p_sha256 is null or p_sha256 !~ '^[0-9a-f]{64}$') then raise exception 'Huella de PDF inválida.';end if;
 update public.circular_documentos set
 pdf_estado=case when p_error is null then 'listo' else 'error' end,
 pdf_ruta=case when p_error is null then p_ruta else pdf_ruta end,
 pdf_sha256=case when p_error is null then p_sha256 else pdf_sha256 end,
 pdf_error=case when p_error is null then null else 'No se pudo completar el PDF. Reintenta sobre esta misma circular.' end,
 intento_hasta=null,intento_token=null
 where circular_id=p_id and intento_token=p_token and pdf_estado='generando';
 get diagnostics n=row_count;return n=1;
end $$;
create function private.comprobar_circular_finalizada()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if exists(select 1 from public.circulares c where c.id=new.id and c.finalizada_en is not null and not exists(select 1 from public.circular_documentos d where d.circular_id=c.id and d.colegio_id=c.colegio_id)) then raise exception 'La finalización requiere el documento institucional validado.';end if;
 return null;
end $$;
create constraint trigger circular_finalizacion_valida after insert or update on public.circulares
 deferrable initially deferred for each row execute function private.comprobar_circular_finalizada();

revoke all on function private.siguiente_circular(uuid),private.validar_segmentos_circular(jsonb),private.validar_datos_circular(jsonb),private.presentar_circular_documento(uuid),private.comprobar_circular_finalizada() from public,anon,authenticated;
revoke all on function public.finalizar_circular_documento(uuid,uuid,uuid,jsonb),public.obtener_circular_documento(uuid),public.listar_circular_documentos(uuid),public.reclamar_pdf_circular(uuid),public.terminar_pdf_circular(uuid,uuid,text,text,text) from public,anon,authenticated;
grant execute on function public.finalizar_circular_documento(uuid,uuid,uuid,jsonb),public.obtener_circular_documento(uuid),public.listar_circular_documentos(uuid) to authenticated;
grant execute on function public.reclamar_pdf_circular(uuid),public.terminar_pdf_circular(uuid,uuid,text,text,text) to service_role;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('circulares','circulares',false,15728640,array['application/pdf','font/ttf','font/otf','application/octet-stream']);
create policy circular_pdf_admin_leer on storage.objects for select to authenticated
 using(bucket_id='circulares' and private.es_admin(private.uuid_o_nulo(split_part(name,'/',1))));
-- Escritura de archivos únicamente desde la función de servidor autenticada.
create function public.invalidar_pdf_circular(p_id uuid,p_sha256 text)
returns boolean language plpgsql security definer set search_path='' as $$
declare n integer;
begin
 update public.circular_documentos set pdf_estado='error',pdf_error='El archivo requiere una nueva generación con el mismo número.' where circular_id=p_id and pdf_estado='listo' and pdf_sha256=p_sha256;
 get diagnostics n=row_count;return n=1;
end $$;
revoke all on function public.invalidar_pdf_circular(uuid,text) from public,anon,authenticated;
grant execute on function public.invalidar_pdf_circular(uuid,text) to service_role;

commit;

