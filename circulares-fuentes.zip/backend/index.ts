import { createClient } from 'npm:@supabase/supabase-js@2.117.3';
import * as pdfLib from 'npm:pdf-lib@1.17.1';
import fontkit from 'npm:@pdf-lib/fontkit@1.1.1';
import './circular-model.js';
import { renderCircularPDF } from './render-pdf.mjs';
import { createCircularHandler } from './handler.mjs';
type CircularModel={validate(value:unknown):Record<string,unknown>;filename(value:Record<string,unknown>):string};
const model=(globalThis as unknown as {ComplexCircularModel:CircularModel}).ComplexCircularModel;
function need(name:string){const value=Deno.env.get(name);if(!value)throw Error('Falta configurar '+name);return value;}
const handler=createCircularHandler({
 createClient,model,
 render:(document:Parameters<typeof renderCircularPDF>[1],assets:Parameters<typeof renderCircularPDF>[2],preview:boolean)=>renderCircularPDF(pdfLib,document,assets,{preview,fontkit}),
 env:{url:need('SUPABASE_URL'),anon:need('SUPABASE_ANON_KEY'),service:need('SUPABASE_SERVICE_ROLE_KEY')}
});
Deno.serve(handler);

