export function createCircularHandler({createClient,model,render,env}){
 const origin='https://complexinteractive55-droid.github.io';
 const headers={'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'authorization, apikey, x-client-info, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Cache-Control':'no-store','Vary':'Origin'};
 const uuid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
 const fail=(message,status=400,uncertain=false)=>Object.assign(Error(message),{status,publicMessage:true,uncertain});
 const reply=(data,status=200,extra={})=>new Response(JSON.stringify(data),{status,headers:{...headers,'Content-Type':'application/json; charset=utf-8',...extra}});
 const hash=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(v=>v.toString(16).padStart(2,'0')).join('');
 async function rpc(client,name,args){const {data,error}=await client.rpc(name,args);if(error){if(error.code==='42501')throw fail('No tienes autorización para esa circular.',403);if(error.code==='P0001'||error.code==='22000')throw fail(error.message,400);if(error.code==='PGRST202')throw fail('El servicio de circulares todavía no está desplegado.',503);throw fail('No se pudo confirmar la operación. Reintenta sin cambiar el contenido.',503,true);}return data;}
 function pathAllowed(path,school){return typeof path==='string'&&path.startsWith(school+'/')&&!path.split('/').some(s=>s==='..'||s==='');}
 async function bytesAt(admin,path,school,expected){if(!pathAllowed(path,school)||!/^[0-9a-f]{64}$/.test(expected||''))throw Error('Configuración de archivo institucional inválida.');const {data,error}=await admin.storage.from('circulares').download(path);if(error||!data||data.size>15728640)throw Error('Archivo institucional no disponible.');const bytes=new Uint8Array(await data.arrayBuffer());if(await hash(bytes)!==expected)throw Error('La huella del archivo no coincide.');return bytes;}
 async function assets(admin,doc){const t=doc.plantilla,a={pdf:await bytesAt(admin,t.ruta,doc.colegio_id,t.sha256)};for(const key of ['normal','negrita']){if(t.fuentes?.[key])a[key]=await bytesAt(admin,t.fuentes[key].ruta,doc.colegio_id,t.fuentes[key].sha256);}return a;}
 async function storedPDF(admin,doc){return bytesAt(admin,doc.pdf_ruta,doc.colegio_id,doc.pdf_sha256);}
 async function download(admin,doc){await storedPDF(admin,doc);const filename=model.filename({...doc,...doc.datos});const {data,error}=await admin.storage.from('circulares').createSignedUrl(doc.pdf_ruta,60,{download:filename});if(error||!data?.signedUrl)throw Error('Descarga temporal no disponible.');return{estado:'listo',guardada:true,id:doc.id,numero:doc.numero,url:data.signedUrl,filename};}
 async function generate(admin,doc){
  let claim=await rpc(admin,'reclamar_pdf_circular',{p_id:doc.id});
  if(claim.accion==='listo'){try{return await download(admin,claim.documento);}catch{await rpc(admin,'invalidar_pdf_circular',{p_id:doc.id,p_sha256:claim.documento.pdf_sha256});claim=await rpc(admin,'reclamar_pdf_circular',{p_id:doc.id});}}
  if(claim.accion==='ocupado')return{estado:'generando',guardada:true,id:doc.id,numero:doc.numero,mensaje:'La circular ya está guardada. Su PDF se está generando; vuelve a consultar esta misma circular.'};
  if(claim.accion!=='generar')throw Error('No se pudo recuperar la generación.');
  try{
   const saved=claim.documento,generated=await render(saved,await assets(admin,saved),false),sha=await hash(generated.bytes);
   const path=saved.colegio_id+'/'+saved.id+'/'+sha+'.pdf';
   const upload=await admin.storage.from('circulares').upload(path,generated.bytes,{contentType:'application/pdf',upsert:false,cacheControl:'0'});
   if(upload.error){await bytesAt(admin,path,saved.colegio_id,sha);}
   else await bytesAt(admin,path,saved.colegio_id,sha);
   const complete=await rpc(admin,'terminar_pdf_circular',{p_id:saved.id,p_token:claim.token,p_ruta:path,p_sha256:sha,p_error:null});
   if(!complete)return{estado:'generando',guardada:true,id:saved.id,numero:saved.numero,mensaje:'La circular está guardada. Otra solicitud está completando el mismo PDF.'};
   return await download(admin,{...saved,pdf_estado:'listo',pdf_ruta:path,pdf_sha256:sha});
  }catch{
   await rpc(admin,'terminar_pdf_circular',{p_id:doc.id,p_token:claim.token,p_ruta:null,p_sha256:null,p_error:'generacion_fallida'}).catch(()=>{});
   return{estado:'pdf_pendiente',guardada:true,id:doc.id,numero:doc.numero,mensaje:'La circular quedó guardada con su número. No se pudo completar el PDF; reintenta sobre esta misma circular.'};
  }
 }
 return async function handle(req){
  let saved=null,operationStarted=false;
  if(req.headers.get('origin')&&req.headers.get('origin')!==origin)return reply({error:'Origen no permitido.'},403);
  if(req.method==='OPTIONS')return new Response('ok',{headers});
  if(req.method!=='POST')return reply({error:'Método no permitido.'},405);
  try{
   const auth=req.headers.get('authorization')||'';if(!/^Bearer\s+\S+$/i.test(auth))throw fail('Inicia sesión para gestionar circulares.',401);
   const user=createClient(env.url,env.anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false}});
   const {data:identity,error:identityError}=await user.auth.getUser();if(identityError||!identity?.user)throw fail('La sesión no es válida. Vuelve a entrar.',401);
   const raw=await req.text();if(new TextEncoder().encode(raw).length>300000)throw fail('El documento es demasiado extenso.',413);
   let body;try{body=JSON.parse(raw);}catch{throw fail('La solicitud no tiene un formato válido.');}
   if(!body||typeof body!=='object'||Array.isArray(body))throw fail('Revisa los datos de la circular.');
   const keys=['finalizar','previsualizar'].includes(body.accion)?['accion','colegio_id','solicitud_id','plantilla_id','datos']:['accion','id'];
   if(Object.keys(body).some(k=>!keys.includes(k)))throw fail('La solicitud contiene campos no permitidos.');
   const admin=createClient(env.url,env.service,{auth:{persistSession:false}});
   if(body.accion==='finalizar'||body.accion==='previsualizar'){
    if(!uuid(body.colegio_id)||!uuid(body.plantilla_id)||(body.accion==='finalizar'&&!uuid(body.solicitud_id)))throw fail('Falta el colegio, la plantilla oficial o la identificación de la operación.');
    const membership=await user.from('miembros').select('perfil_id').eq('colegio_id',body.colegio_id).eq('perfil_id',identity.user.id).eq('rol','admin').eq('activo',true).maybeSingle();
    if(membership.error||!membership.data)throw fail('Solo Administración puede finalizar circulares de este colegio.',403);
    let data;try{data=model.validate(body.datos);}catch(e){throw fail(e.message);}
    const previous=body.accion==='finalizar'?await user.from('circular_documentos').select('circular_id').eq('colegio_id',body.colegio_id).eq('solicitud_id',body.solicitud_id).maybeSingle():{data:null,error:null};
    if(previous.error)throw fail('No se pudo comprobar el estado de la operación. Reintenta con la misma solicitud.',503,true);
    if(!previous.data){
     const template=await user.from('circular_plantillas').select('*').eq('colegio_id',body.colegio_id).eq('id',body.plantilla_id).eq('estado','aprobada').maybeSingle();
     if(template.error||!template.data)throw fail('Falta la plantilla institucional oficial aprobada.');
     const school=await user.from('colegios').select('id,nombre,nit,ciudad').eq('id',body.colegio_id).single();
     if(school.error||!school.data)throw fail('No se pudo validar la institución.',403);
     const draft={colegio_id:body.colegio_id,datos:data,institucion:school.data,plantilla:template.data,numero:null};
     let preview;try{preview=await render(draft,await assets(admin,draft),true);}catch{throw fail('No se pudo componer la circular con la plantilla y las fuentes oficiales. Revisa la vista previa antes de finalizar.',422);}
     if(body.accion==='previsualizar')return new Response(preview.bytes,{headers:{...headers,'Content-Type':'application/pdf','Content-Disposition':'inline; filename="'+model.filename(data)+'"'}});
    }
    operationStarted=true;
    saved=await rpc(user,'finalizar_circular_documento',{p_colegio:body.colegio_id,p_solicitud:body.solicitud_id,p_plantilla:body.plantilla_id,p_datos:data});
    const result=await generate(admin,saved);return reply(result,result.estado==='listo'?200:202);
   }
   if(!['reintentar','descargar'].includes(body.accion)||!uuid(body.id))throw fail('La operación solicitada no es válida.');
   saved=await rpc(user,'obtener_circular_documento',{p_id:body.id});if(!saved)throw fail('No existe esa circular.',404);
   if(body.accion==='reintentar'){const result=await generate(admin,saved);return reply(result,result.estado==='listo'?200:202);}
   if(saved.pdf_estado!=='listo')return reply({estado:'pdf_pendiente',guardada:true,id:saved.id,numero:saved.numero,mensaje:'La circular está guardada. Reintenta la generación del PDF.'},202);
   try{return reply(await download(admin,saved));}catch{await rpc(admin,'invalidar_pdf_circular',{p_id:saved.id,p_sha256:saved.pdf_sha256});return reply({estado:'pdf_pendiente',guardada:true,id:saved.id,numero:saved.numero,mensaje:'El archivo no está disponible. Reintenta el PDF con este mismo número.'},202);}
  }catch(error){
   if(saved)return reply({estado:'pdf_pendiente',guardada:true,id:saved.id,numero:saved.numero,mensaje:'La circular está guardada. No se pudo confirmar el PDF; vuelve a intentarlo.'},202);
   return reply({error:error.publicMessage?error.message:'No se pudo completar la solicitud.',guardada:error.uncertain?null:false,reintentar_operacion:Boolean(error.uncertain)},error.status||500);
  }
 };
}

