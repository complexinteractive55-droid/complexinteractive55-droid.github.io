from pathlib import Path
from pypdf import PdfReader
from PIL import Image, ImageOps, ImageDraw
import subprocess
root=Path('work/circulares/feature/tests/fixtures')
out=Path('work/circulares/feature/tmp/pdfs');out.mkdir(parents=True,exist_ok=True)
poppler=Path(r'C:/Users/faave/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
for name in ['circular-corta-prueba','circular-larga-prueba','circular-vista-previa-prueba']:
    reader=PdfReader(root/(name+'.pdf'))
    text='\n'.join(p.extract_text() or '' for p in reader.pages)
    assert 'María Núñez' in text and 'Coordinadora académica' in text
    if name!='circular-larga-prueba':
        assert 'áéíóú, ñ, ü' in text and 'Segunda actividad en negrita' in text
    for i,p in enumerate(reader.pages,1):
        assert f'Página {i} de {len(reader.pages)}' in p.extract_text()
    subprocess.run([str(poppler),'-r','75','-png',str(root/(name+'.pdf')),str(out/name)],check=True,capture_output=True)
    print(f'OK extracción de texto y numeración de {name}: {len(reader.pages)} páginas')
images=sorted(out.glob('circular-larga-prueba-*.png'))
w,h=306,426
sheet=Image.new('RGB',(w*4,h*2),'#d8dde5');draw=ImageDraw.Draw(sheet)
for i,file in enumerate(images):
    im=Image.open(file).convert('RGB');im.thumbnail((w-16,h-30))
    x=(i%4)*w+8;y=(i//4)*h+22;sheet.paste(im,(x,y));draw.text((x,y-18),f'Página {i+1} - PRUEBA',(0,0,0))
sheet.save(out/'contacto-larga.jpg',quality=92)
