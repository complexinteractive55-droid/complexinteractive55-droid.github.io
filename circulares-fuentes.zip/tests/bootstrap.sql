-- Entorno desechable para pruebas: reproduce solo el contrato del módulo.
-- No contiene datos reales ni se debe ejecutar sobre el Supabase del colegio.
create role anon nologin;
create role authenticated nologin;
create role service_role nologin bypassrls;
create schema auth;create schema private;create schema storage;
grant usage on schema public,private,auth,storage to anon,authenticated,service_role;
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
create type public.rol_colegio as enum('admin','profesor','acudiente','estudiante','enfermeria','director_seccion');
create table public.perfiles(id uuid primary key,nombres text not null default '',apellidos text not null default '');
create table public.colegios(id uuid primary key default gen_random_uuid(),nombre text not null,nit text,ciudad text);
create table public.miembros(colegio_id uuid references public.colegios(id),perfil_id uuid references public.perfiles(id),rol public.rol_colegio,activo boolean not null default true,primary key(colegio_id,perfil_id,rol));
create table public.circulares(id uuid primary key default gen_random_uuid(),colegio_id uuid not null references public.colegios(id) on delete cascade,autor_id uuid references public.perfiles(id) on delete set null,titulo text not null,cuerpo text not null,sede_id uuid,grado_id uuid,curso_id uuid,roles public.rol_colegio[],publicada_en timestamptz,creado_en timestamptz not null default now(),numero integer,unique(colegio_id,id));
create function private.es_admin(p_colegio uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.miembros m where m.colegio_id=p_colegio and m.perfil_id=(select auth.uid()) and m.rol='admin' and m.activo)$$;
create function private.uuid_o_nulo(p text) returns uuid language plpgsql immutable set search_path='' as $$begin return p::uuid;exception when invalid_text_representation then return null;end$$;
create function private.numerar_circular() returns trigger language plpgsql security definer set search_path='' as $$begin if new.publicada_en is not null and new.numero is null then perform pg_advisory_xact_lock(hashtext('circular_'||new.colegio_id::text));select coalesce(max(c.numero),0)+1 into new.numero from public.circulares c where c.colegio_id=new.colegio_id;end if;return new;end$$;
create trigger numerar_circular before insert or update on public.circulares for each row execute function private.numerar_circular();
alter table public.colegios enable row level security;alter table public.miembros enable row level security;alter table public.circulares enable row level security;
create policy colegio_ver on public.colegios for select to authenticated using(private.es_admin(id));
create policy miembros_ver on public.miembros for select to authenticated using(perfil_id=(select auth.uid()) or private.es_admin(colegio_id));
create policy circular_admin on public.circulares for all to authenticated using(private.es_admin(colegio_id)) with check(private.es_admin(colegio_id));
create policy circular_ver on public.circulares for select to authenticated using(publicada_en is not null and exists(select 1 from public.miembros m where m.colegio_id=circulares.colegio_id and m.perfil_id=(select auth.uid()) and m.activo and (circulares.roles is null or m.rol=any(circulares.roles))));
create table storage.buckets(id text primary key,name text not null,public boolean default false,file_size_limit bigint,allowed_mime_types text[]);
create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text references storage.buckets(id),name text not null,unique(bucket_id,name));
alter table storage.objects enable row level security;
grant select,insert,update,delete on public.circulares to authenticated;
grant select on public.colegios,public.miembros to authenticated;
grant all on all tables in schema public,storage to service_role;
grant select on storage.objects to anon,authenticated;
insert into public.colegios(id,nombre,ciudad) values('11111111-1111-4111-8111-111111111111','INSTITUCIÓN SINTÉTICA A','Ciudad de prueba'),('22222222-2222-4222-8222-222222222222','INSTITUCIÓN SINTÉTICA B','Ciudad de prueba');
insert into public.perfiles(id,nombres) values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Admin A'),('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','Admin B'),('cccccccc-cccc-4ccc-8ccc-cccccccccccc','Profesor A'),('dddddddd-dddd-4ddd-8ddd-dddddddddddd','Admin inactivo');
insert into public.miembros(colegio_id,perfil_id,rol,activo) values('11111111-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','admin',true),('22222222-2222-4222-8222-222222222222','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','admin',true),('11111111-1111-4111-8111-111111111111','cccccccc-cccc-4ccc-8ccc-cccccccccccc','profesor',true),('11111111-1111-4111-8111-111111111111','dddddddd-dddd-4ddd-8ddd-dddddddddddd','admin',false);
insert into public.circulares(colegio_id,autor_id,titulo,cuerpo,publicada_en) values('11111111-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Circular previa 1','Contenido previo de prueba',now()),('11111111-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Circular previa 2','Contenido previo de prueba',now());

