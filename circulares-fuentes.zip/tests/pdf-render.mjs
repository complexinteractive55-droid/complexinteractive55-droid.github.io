import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {renderCircularPDF} from '../backend/render-pdf.mjs';
const require=createRequire(import.meta.url);
const lib=require(process.env.CIRC_PDF_LIB||'C:/Users/faave/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/pdf-lib');
const {PDFDocument,StandardFonts,rgb}=lib,root=path.dirname(fileURLToPath(import.meta.url)),dir=path.join(root,'fixtures');
await fs.mkdir(dir,{recursive:true});
const template=await PDFDocument.create(),font=await template.embedFont(StandardFonts.Helvetica);
for(let n=0;n<2;n++){const p=template.addPage([612,792]);p.drawRectangle({x:40,y:728,width:532,height:44,color:rgb(.9,.94,.98)});p.drawText('PLANTILLA SINTETICA - SOLO PRUEBAS',{x:50,y:748,size:13,font});p.drawText(n?'PAGINA DE CONTINUACION DE PRUEBA':'PRIMERA PAGINA DE PRUEBA',{x:50,y:733,size:9,font});p.drawLine({start:{x:54,y:55},end:{x:558,y:55},thickness:.7});p.drawText('Sin validez institucional. No es el membrete del colegio.',{x:54,y:38,size:8,font});}
const templateBytes=await template.save({useObjectStreams:false});await fs.writeFile(path.join(dir,'plantilla-sintetica.pdf'),templateBytes);
const config={formato_version:1,primera:{pagina:0,area:{x:54,y:80,ancho:504,alto:620}},continuacion:{pagina:1,area:{x:64,y:80,ancho:484,alto:640}},tipografia:{normal:'Helvetica',negrita:'Helvetica-Bold',tamano:11,interlineado:15,espacio_parrafo:6},firma:{espacio:30,linea:true,ancho_linea:180},paginacion:{mostrar:true,formato:'Página {pagina} de {paginas}',x:400,y:62,ancho:150,tamano:9,alineacion:'derecha'}};
const paragraph=t=>({tipo:'parrafo',segmentos:[{texto:t,negrita:false}]});
const doc={numero:17,finalizada_en:'2026-10-27T11:00:00.000Z',institucion:{nombre:'INSTITUCIÓN SINTÉTICA DE PRUEBAS'},plantilla:{configuracion:config},datos:{titulo:'Información académica: José, Núñez y educación',fecha_emision:'2026-10-27',destinatarios:'Familias de educación básica',dependencia:'Coordinación académica',responsable:'María Núñez',cargo:'Coordinadora académica',contenido:{version:1,bloques:[{tipo:'parrafo',segmentos:[{texto:'¡Atención! ',negrita:true},{texto:'Información en español: áéíóú, ñ, ü y ¿cuándo?',negrita:false}]},{tipo:'lista',ordenada:true,elementos:[{segmentos:[{texto:'Primera actividad',negrita:false}]},{segmentos:[{texto:'Segunda actividad en negrita',negrita:true}]}]},{tipo:'lista',ordenada:false,elementos:[{segmentos:[{texto:'Información adicional para las familias.',negrita:false}]}]}]}}};
const short=await renderCircularPDF(lib,doc,{pdf:templateBytes});assert.equal(short.pages,1);await fs.writeFile(path.join(dir,'circular-corta-prueba.pdf'),short.bytes);
const repeat=await renderCircularPDF(lib,doc,{pdf:templateBytes});assert.deepEqual(Buffer.from(short.bytes),Buffer.from(repeat.bytes),'Reintentos sobre la misma instantánea deben producir el mismo archivo.');
const long=structuredClone(doc);long.datos.contenido.bloques=Array.from({length:65},(_,i)=>paragraph('Párrafo '+(i+1)+'. '+('La educación, la participación y la comunicación fortalecen a las familias. ').repeat(4)));
long.datos.contenido.bloques.push(paragraph('PALABRAMUYLARGA'.repeat(85)));
const multi=await renderCircularPDF(lib,long,{pdf:templateBytes});assert.ok(multi.pages>=4);assert.ok(multi.pages<100);await fs.writeFile(path.join(dir,'circular-larga-prueba.pdf'),multi.bytes);
const preview=await renderCircularPDF(lib,{...doc,numero:null},{pdf:templateBytes},{preview:true});await fs.writeFile(path.join(dir,'circular-vista-previa-prueba.pdf'),preview.bytes);
for(const result of [short,multi,preview]){for(let i=1;i<=result.pages;i++)assert.ok(result.trace.some(t=>t.page===i),'Ninguna página puede contener solo membrete vacío.');for(const t of result.trace){assert.ok(t.x>=t.area.x-.1);assert.ok(t.x+t.width<=t.area.x+t.area.ancho+.1,t.text);assert.ok(t.y>=t.area.y,t.text);assert.ok(t.y+t.size<=t.area.y+t.area.alto+.1,t.text);}}
const bad=structuredClone(doc);bad.plantilla.configuracion.continuacion.area.x=600;await assert.rejects(()=>renderCircularPDF(lib,bad,{pdf:templateBytes}),/área de texto/);
const glyph=structuredClone(doc);glyph.datos.contenido.bloques=[paragraph('Emoji no soportado por la fuente de prueba 🙂')];await assert.rejects(()=>renderCircularPDF(lib,glyph,{pdf:templateBytes}),/carácter/);
const missing=structuredClone(doc);delete missing.plantilla;await assert.rejects(()=>renderCircularPDF(lib,missing,{pdf:templateBytes}),/plantilla oficial/);
await fs.writeFile(path.join(dir,'verificacion-layout.json'),JSON.stringify({shortPages:short.pages,longPages:multi.pages,previewPages:preview.pages,longCharacters:long.datos.contenido.bloques.reduce((n,b)=>n+b.segmentos.reduce((x,s)=>x+s.texto.length,0),0),traceWithinBounds:true,noBlankOverflowPages:true,syntheticTemplateOnly:true},null,2));
console.log('OK PDF corto, largo, español, listas, negrita, reintento determinista, límites, continuación y bloqueo sin plantilla oficial. Páginas largas: '+multi.pages+'. Plantilla SINTÉTICA, no institucional.');

