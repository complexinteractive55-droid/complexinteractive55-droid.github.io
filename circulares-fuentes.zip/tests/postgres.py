"""Pruebas reales de PostgreSQL en una base DESECHABLE. Nunca producción."""
import json,os,subprocess,uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
DSN=os.environ.get('CIRCULAR_TEST_DATABASE_URL','')
if not DSN or 'circular_tests' not in DSN:raise SystemExit('Se requiere una base aislada cuyo nombre contenga circular_tests.')
A='11111111-1111-4111-8111-111111111111';B='22222222-2222-4222-8222-222222222222'
ADMIN='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';OUT='bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';TEACHER='cccccccc-cccc-4ccc-8ccc-cccccccccccc';INACTIVE='dddddddd-dddd-4ddd-8ddd-dddddddddddd';T='33333333-3333-4333-8333-333333333333'
DATA={'titulo':'Información académica — prueba','destinatarios':'Familias','dependencia':'Coordinación','responsable':'María Núñez','cargo':'Coordinadora','fecha_emision':'2026-10-27','contenido':{'version':1,'bloques':[{'tipo':'parrafo','segmentos':[{'texto':'¡Atención! Educación y español: áéíóú, ñ, ü.','negrita':True}]}]}}
def lit(s):return "'"+str(s).replace("'","''")+"'"
def run(sql,actor=None,role=None,ok=True):
    prefix='begin;'
    if actor:prefix+='select set_config('+lit('request.jwt.claim.sub')+','+lit(actor)+',true);'
    if role or actor:prefix+='set local role '+(role or 'authenticated')+';'
    p=subprocess.run(['psql',DSN,'-X','-q','-t','-A','-v','ON_ERROR_STOP=1','-c',prefix+sql+';commit;'],capture_output=True,text=True)
    if ok and p.returncode:raise AssertionError(p.stderr)
    if not ok:
        assert p.returncode, 'La operación debió ser rechazada'
        return p.stderr
    lines=[l for l in p.stdout.splitlines() if l.strip()]
    return lines[-1] if lines else ''
def finalize(op=None,actor=ADMIN,school=A,data=DATA):
    return json.loads(run('select public.finalizar_circular_documento('+','.join([lit(school),lit(op or uuid.uuid4()),lit(T),lit(json.dumps(data,ensure_ascii=False))+'::jsonb'])+')',actor))
def rejected(sql,actor=ADMIN,role=None):return run(sql,actor,role,ok=False)
def count():return int(run("select count(*) from public.circular_documentos"))
def next_counter():return int(run("select ultimo from private.circular_consecutivos where colegio_id="+lit(A)))
def case(name,fn):
    fn();print('OK '+name,flush=True)
# Fuentes SQL explícitas; no se aceptan comandos sobre otro servidor.
for file in [ROOT/'bootstrap.sql',ROOT.parent/'backend'/'circulares.sql']:
    p=subprocess.run(['psql',DSN,'-X','-q','-v','ON_ERROR_STOP=1','-f',str(file)],capture_output=True,text=True)
    if p.returncode:raise AssertionError(p.stderr)
run("insert into public.circular_plantillas(id,colegio_id,nombre,revision,estado,ruta,sha256,configuracion,aprobada_por,aprobada_en) values("+','.join([lit(T),lit(A),lit('PLANTILLA SINTÉTICA - SOLO PRUEBAS'),'1',lit('aprobada'),lit(A+'/plantillas/test.pdf'),lit('a'*64),lit('{"formato_version":1}')+'::jsonb',lit(ADMIN),'now()'])+')')
operation=str(uuid.uuid4())
with ThreadPoolExecutor(max_workers=12) as pool: repeated=list(pool.map(lambda _:finalize(operation),range(18)))
assert count()==1 and {x['numero'] for x in repeated}=={3} and len({x['id'] for x in repeated})==1
print('OK 18 conexiones concurrentes con la misma operación: una circular, número 3, tras las dos previas',flush=True)
doc=repeated[0];ID=doc['id']
with ThreadPoolExecutor(max_workers=12) as pool: distinct=list(pool.map(lambda _:finalize(),range(20)))
assert sorted(x['numero'] for x in distinct)==list(range(4,24)) and count()==21
print('OK 20 conexiones concurrentes con operaciones distintas: números únicos 4–23',flush=True)
before=next_counter()
for actor in [OUT,TEACHER,INACTIVE]:
    rejected('select public.finalizar_circular_documento('+','.join([lit(A),lit(uuid.uuid4()),lit(T),lit(json.dumps(DATA))+'::jsonb'])+')',actor)
    rejected('select public.obtener_circular_documento('+lit(ID)+')',actor)
    assert run('select count(*) from public.circular_documentos',actor)=='0'
assert next_counter()==before
print('OK otro colegio, profesor y administrador inactivo: RPC y RLS bloquean; no consumen número',flush=True)
rejected('select public.finalizar_circular_documento('+','.join([lit(A),lit(uuid.uuid4()),lit(T),lit(json.dumps(DATA))+'::jsonb'])+')',None,'anon')
for bad in [{**DATA,'titulo':''},{**DATA,'fecha_emision':'2026-02-30'},{**DATA,'numero':800},{**DATA,'contenido':{'version':1,'bloques':[{'tipo':'html','html':'<b>x</b>'}]}}]:
    rejected('select public.finalizar_circular_documento('+','.join([lit(A),lit(uuid.uuid4()),lit(T),lit(json.dumps(bad))+'::jsonb'])+')')
assert next_counter()==before
print('OK validación del servidor y denegación anónima: transacciones sin números consumidos',flush=True)
rejected('select public.finalizar_circular_documento('+','.join([lit(A),lit(operation),lit(T),lit(json.dumps({**DATA,'titulo':'Otro asunto'}))+'::jsonb'])+')')
rejected("insert into public.circulares(colegio_id,titulo,cuerpo,numero) values("+lit(A)+",'Número manual','Prueba',999)")
rejected("update public.circulares set numero=999 where id="+lit(ID))
rejected("update public.circulares set cuerpo='Otro contenido' where id="+lit(ID))
rejected("insert into public.circulares(colegio_id,titulo,cuerpo,finalizada_en) values("+lit(A)+",'Finalización directa','Prueba',now())")
assert count()==21 and next_counter()==before
print('OK contenido finalizado, número manual y bypass de finalización bloqueados',flush=True)
assert run('select count(*) from public.circulares c join public.circular_documentos d on d.circular_id=c.id where c.publicada_en is not null')=='0'
assert run('select count(*) from public.circulares where numero in(1,2) and publicada_en is not null')=='2'
print('OK las nuevas finalizaciones no publican; circulares previas conservadas',flush=True)
# El flujo previo de publicar borradores continúa con el contador compartido.
run("insert into public.circulares(id,colegio_id,titulo,cuerpo) values('77777777-7777-4777-8777-777777777777',"+lit(A)+",'Borrador anterior','Prueba')")
run("update public.circulares set publicada_en=now() where id='77777777-7777-4777-8777-777777777777'",ADMIN)
assert run("select numero from public.circulares where id='77777777-7777-4777-8777-777777777777'")=='24'
run("delete from public.circulares where id='77777777-7777-4777-8777-777777777777'",ADMIN)
assert finalize()['numero']==25
print('OK publicación previa compatible y número eliminado no reutilizado',flush=True)
for function in ['reclamar_pdf_circular('+lit(ID)+')','terminar_pdf_circular('+','.join([lit(ID),lit(uuid.uuid4()),'null','null',lit('fallo')])+')','invalidar_pdf_circular('+lit(ID)+','+lit('a'*64)+')']:
    rejected('select public.'+function)
claim=json.loads(run('select public.reclamar_pdf_circular('+lit(ID)+')',role='service_role'))
assert claim['accion']=='generar'
assert json.loads(run('select public.reclamar_pdf_circular('+lit(ID)+')',role='service_role'))['accion']=='ocupado'
old=claim['token']
assert run('select public.terminar_pdf_circular('+','.join([lit(ID),lit(old),'null','null',lit('fallo_sintetico')])+')',role='service_role')=='t'
assert json.loads(run('select public.obtener_circular_documento('+lit(ID)+')',ADMIN))['pdf_estado']=='error'
again=json.loads(run('select public.reclamar_pdf_circular('+lit(ID)+')',role='service_role'))
assert again['accion']=='generar' and again['token']!=old
assert run('select public.terminar_pdf_circular('+','.join([lit(ID),lit(old),lit(A+'/'+ID+'/test.pdf'),lit('a'*64),'null'])+')',role='service_role')=='f'
assert run('select public.terminar_pdf_circular('+','.join([lit(ID),lit(again['token']),lit(A+'/'+ID+'/test.pdf'),lit('a'*64),'null'])+')',role='service_role')=='t'
ready=json.loads(run('select public.obtener_circular_documento('+lit(ID)+')',ADMIN))
assert ready['pdf_estado']=='listo' and ready['numero']==3 and next_counter()==25
print('OK leases, fallo, reintento con mismo número y token obsoleto; RPC reservadas al servidor',flush=True)
run("insert into storage.objects(bucket_id,name) values('circulares',"+lit(A+'/'+ID+'/test.pdf')+')')
assert run("select count(*) from storage.objects where bucket_id='circulares'",ADMIN)=='1'
for actor in [OUT,TEACHER,INACTIVE]:assert run("select count(*) from storage.objects where bucket_id='circulares'",actor)=='0'
assert run("select count(*) from storage.objects where bucket_id='circulares'",role='anon')=='0'
assert run("select public from storage.buckets where id='circulares'")=='f'
print('OK PDF privado por institución y rol, incluido acceso anónimo denegado',flush=True)
run("update public.circular_plantillas set estado='archivada' where id="+lit(T))
assert finalize(operation)['id']==ID
rejected('select public.finalizar_circular_documento('+','.join([lit(A),lit(uuid.uuid4()),lit(T),lit(json.dumps(DATA))+'::jsonb'])+')')
assert next_counter()==25
print('OK reintento histórico conserva documento aun con plantilla archivada; nuevas emisiones bloqueadas',flush=True)
# Mantener la semántica previa de ON DELETE SET NULL del autor.
rejected('update public.circulares set autor_id='+lit(OUT)+' where id='+lit(ID),ADMIN)
audit_before=run('select md5(datos::text) from public.circular_documentos where circular_id='+lit(ID))
run('delete from public.miembros where perfil_id='+lit(ADMIN))
run('delete from public.perfiles where id='+lit(ADMIN))
assert run('select autor_id is null from public.circulares where id='+lit(ID))=='t'
assert run('select aprobada_por from public.circular_plantillas where id='+lit(T))==ADMIN
assert run('select md5(datos::text) from public.circular_documentos where circular_id='+lit(ID))==audit_before
assert next_counter()==25
print('OK baja del perfil no bloqueada; identidad histórica de aprobación y contenido preservados; autor no reasignable',flush=True)
print('RESULTADO: integración PostgreSQL, concurrencia real y políticas comprobadas en circular_tests.',flush=True)

